#ifndef GLES2_GL2_H
#define GLES2_GL2_H

typedef float GLfloat;
typedef int GLint;
typedef unsigned int GLuint;
typedef unsigned int GLbitfield;
typedef unsigned char GLubyte;
typedef int GLsizei;
typedef unsigned int GLenum;

#define GL_COLOR_BUFFER_BIT 0x00004000
#define GL_DEPTH_BUFFER_BIT 0x00000100

#endif
