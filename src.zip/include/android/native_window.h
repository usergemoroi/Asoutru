#ifndef ANDROID_NATIVE_WINDOW_H
#define ANDROID_NATIVE_WINDOW_H

struct ANativeWindow;
typedef struct ANativeWindow ANativeWindow;

#endif
