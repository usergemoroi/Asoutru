#ifndef EGL_EGL_H
#define EGL_EGL_H

typedef void* EGLDisplay;
typedef void* EGLConfig;
typedef void* EGLContext;
typedef void* EGLSurface;

#endif
